import { Component, OnInit } from '@angular/core';
import { CountryService } from './../country.service'

@Component({
    selector: 'auto',
    templateUrl: './auto-complete-demo.component.html',
    styleUrls: ['./auto-complete-demo.component.scss']
})
export class AutoCompleteDemoComponent implements OnInit {

    ngOnInit() {
    }

    country: any;

    countries: any[]=[];

    filteredCountriesSingle: any[];

    filteredCountriesMultiple: any[];

    brands: string[] = ['Audi', 'BMW', 'Fiat', 'Ford', 'Honda', 'Jaguar', 'Mercedes', 'Renault', 'Volvo', 'VW'];

    filteredBrands: any[];

    brand: string;

    constructor(private countryService: CountryService) { }

    filterCountrySingle(event) {
        let query = event.query;
        this.countryService.getCountries().then(countries => {
            this.filteredCountriesSingle = this.filterCountry(query, countries);
        });
    }

    filterCountryMultiple(event) {
        let query = event.query;
        //   alert('called')
        this.countryService.getCountries().then(countries => {

            this.filteredCountriesMultiple = this.filterCountry(query, countries);
            //   let obj={
            //       name:query,
            //       code:query
            //   }
            //   this.filteredCountriesMultiple.push(obj)
            //   console.log(this.filteredCountriesMultiple);

        });
    }

    filterCountry(query, countries: any[]): any[] {
        //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
        let filtered: any[] = [];
        for (let i = 0; i < countries.length; i++) {
            let country = countries[i];


            if (country.name.toLowerCase().includes(query.toLowerCase())) {
                // console.log(query+" "+country.name);
                filtered.push(country);
            }
            //   else{
            //     filtered.push(query);
            //   }
        }
        return filtered;
    }

    filterBrands(event) {
        this.filteredBrands = [];
        for (let i = 0; i < this.brands.length; i++) {
            let brand = this.brands[i];
            if (brand.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                this.filteredBrands.push(brand);
            }
        }
    }

    onKeyUp(event) {
        let slectedValue = event.srcElement.value
        console.log(event.srcElement.value);

        if (event.key == 'Enter') {
            let obj = {
                name: slectedValue,
                code: slectedValue
            }
            let suggestedCountry = false;
            for (let i = 0; i < this.filteredCountriesMultiple.length; i++) {
                if (this.filteredCountriesMultiple[i].name == slectedValue)
                    suggestedCountry = true;
            }
            
            console.log("suggestedCountry " + suggestedCountry);
            if(event.srcElement.value!=''){
                console.log(obj);
                console.log(this.countries);
                
                this.countries.push(obj)
            }
            
            // document.getElementsByClassName('ui-autocomplete-input-token')[0]['innerText']=''
            // document.get
            document.getElementById('hai').getElementsByClassName('undefined')[0]['value'] = ''

        }

    }
}
