import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CountryService {

  constructor(private http: HttpClient) {}

  getCountries() {
      return this.http.get('assets/data/countries.json')
                  .toPromise()
                  .then(res => <any[]> res)
                  .then(data => { 
                    // console.log(data['data'])
                    return data['data']; });
  }
}
